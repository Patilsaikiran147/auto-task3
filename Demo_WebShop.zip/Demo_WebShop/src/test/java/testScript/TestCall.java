package testScript;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.github.dockerjava.api.model.Driver;


public class TestCall extends Reusability {


	@Test
	public void run() {
		
	}
}
