package Utils;

public interface Constants {
			String url="https://adactinhotelapp.com/HotelAppBuild2/";
}
