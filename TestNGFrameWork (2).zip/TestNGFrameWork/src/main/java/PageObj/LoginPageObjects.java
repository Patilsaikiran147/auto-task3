package PageObj;

public interface LoginPageObjects {
                        String username ="username";
                        String password ="paswword";
                        String login    ="login";
                     }
 