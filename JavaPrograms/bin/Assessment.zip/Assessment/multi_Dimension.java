package Assessment;

import java.util.Scanner;

public class multi_Dimension {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[][] = new int[3][3];
		int sum=0;
		System.out.println("Enter the values: ");
		Scanner sc = new Scanner(System.in);
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a.length; j++) {
				a[i][j] = sc.nextInt();
				System.out.print(a[i][j] + " ");
				sum+= a[0][j];
			}
			System.out.println("="+sum);
			System.out.println();
			
		}
		
	}
}
