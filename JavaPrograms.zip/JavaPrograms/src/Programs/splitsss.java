package Programs;

public class splitsss {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			String str = "I am an indian";
			String spl[] =str.split(" ");
			for(int i=spl.length-1;i>=0;i--) {
				System.out.println(spl[i]+" ");
			}
					}

}
