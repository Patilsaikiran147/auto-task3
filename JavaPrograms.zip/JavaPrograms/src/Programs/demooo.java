package Programs;

public class demooo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 100;
		String str = Integer.toString(a);
		System.out.println(str);
	}

}
