package Programs;

public class swap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=10, y=5;
	     x=x+y;
	     y=x-y;
	     x=x-y;
	  System.out.println(x+" "+y);
	}

}
