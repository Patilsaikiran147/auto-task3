package Programs;

public class Reversebuilder {
		public static void main(String[] args) {
			StringBuilder sb = new StringBuilder("ojas123");
			StringBuilder s =sb.reverse();
			System.out.println(s);
		}
}
