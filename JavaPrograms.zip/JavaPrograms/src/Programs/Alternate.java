package Programs;

public class Alternate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			int tr[]= {1,2,3,4,5,6,7};
			int n = tr.length;
			for(int i=0;i<n;i++) {
			System.out.println(tr[i++]);
			}
//			for(int)
//		int ar[]= {2,3,4,5,6,7,8};
//		for(int i =0; i<ar.length-1;i++) {
//			if(ar[i]%2 == 0) {
//				System.out.println(ar[i]);
			}
		
	
	}

