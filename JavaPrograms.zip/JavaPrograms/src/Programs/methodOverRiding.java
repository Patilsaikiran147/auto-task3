package Programs;

public class methodOverRiding {
	public void print()
	{
	 System.out.println("parent class");
	}
	}
	

