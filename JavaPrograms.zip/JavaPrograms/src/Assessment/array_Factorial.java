package Assessment;

public class array_Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[] = new int [6];
		int fact = 1;
		for(int i=1; i<a.length;i++) {
			fact = fact * i;
		
	}
		System.out.println("factorial "+" is "+fact);
	}
}
