package PageObj;

public interface HomePageObjects {

}
